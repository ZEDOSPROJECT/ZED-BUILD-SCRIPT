#ifndef SAGE_GL_H
#  define SAGE_GL_H 1
#  ifdef __APPLE__
#    include <OpenGL/gl.h>
#  else
#    include <GL/gl.h>
#  endif
#endif
